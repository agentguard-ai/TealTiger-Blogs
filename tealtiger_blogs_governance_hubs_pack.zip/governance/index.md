---
layout: page
title: "AI Governance — Start Here"
permalink: /governance/
---

_Last updated: 2026-03-03

AI governance is a **complete lifecycle discipline**: policies, accountability, risk/impact assessment, measurement, runtime controls, evidence, cost governance, data governance, and sustainability.

This hub organizes the blog into governance domains. Start with the hubs below.

## Hubs
- [Runtime Governance (Agents & Execution Boundaries)](/governance/runtime.html)
- [Cost & Economic Governance](/governance/cost.html)
- [Evidence & Audit (Logging vs Governance)](/governance/evidence.html)
- [Security as a Domain (Inside Governance)](/governance/security.html)
- [Frameworks & Standards (Reference)](/governance/frameworks.html)
- [Sustainability & Environmental Impact](/governance/sustainability.html)

---

## Foundational posts (current)
- [Blast-radius control for AI agents](/2026/02/27/blast-radius-control-for-ai-agents.html)
- [Why runtime enforcement beats static evaluation](/2026/02/27/why-runtime-enforcement-beats-static-evaluation.html)
- [Zero Trust agentic AI](/2026/02/27/zero-trust-agentic-ai.html)
- [Cost is a security boundary](/2026/02/27/cost-is-a-security-boundary.html)
- [Logging is not governance](/2026/02/27/logging-is-not-governance.html)
- [Why prompt-only guardrails fail](/2026/02/27/why-prompt-only-guardrails-fail.html)

