---
layout: page
title: "Sustainability & Environmental Impact"
permalink: /governance/sustainability.html
---

_Last updated: 2026-03-03

AI governance also includes **environmental sustainability**: energy use, compute efficiency, and lifecycle impact of AI systems.

## Planned topics
- Sustainable AI / Green AI concepts
- Measuring energy use and cost-of-inference
- Governance policies for sustainable usage

