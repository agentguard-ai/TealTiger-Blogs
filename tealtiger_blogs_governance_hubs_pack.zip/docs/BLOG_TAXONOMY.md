# Blog Taxonomy — AI Governance (Complete)

_Last updated: 2026-03-03

AI governance here is not limited to security. It covers organizational governance, risk, assurance, runtime controls, evidence, cost governance, data governance, and sustainability.

## Pillars (Hubs)
1. Governance Operating Model (GOVERN)
2. Risk & Impact Mapping (MAP)
3. Measurement & Assurance (MEASURE)
4. Runtime Governance & Controls (MANAGE)
5. Security (domain inside governance)
6. Data Governance & Privacy
7. Cost & Economic Governance
8. Sustainability
9. Cookbook / Implementation
10. Research & Market Watch

## Tag suggestions
- ai-governance, agentic-ai, runtime-governance, evidence, audit, policy
- cost-governance, unbounded-consumption, finops
- data-governance, privacy
- security, prompt-injection, owasp
- sustainability, green-ai

